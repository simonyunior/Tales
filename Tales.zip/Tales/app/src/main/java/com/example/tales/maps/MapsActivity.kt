package com.example.tales.maps

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.tales.R
import com.example.tales.databinding.ActivityMapsBinding
import com.example.tales.model.Story
import com.example.tales.viewmodel.StoryViewModel
import com.example.tales.viewmodel.ViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import androidx.lifecycle.ViewModelProvider
import com.example.tales.Injector
import kotlinx.coroutines.launch

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var storyViewModel: StoryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize ViewModel
        storyViewModel = ViewModelProvider(this, ViewModelFactory(Injector.provideStoryRepository(this))).get(StoryViewModel::class.java)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Set default location (e.g., Sydney)
        val defaultLocation = LatLng(-34.0, 151.0)
        mMap.moveCamera(CameraUpdateFactory.newLatLng(defaultLocation))

        // Load stories with location and add markers
        loadStoriesWithLocation()
    }

    private fun loadStoriesWithLocation() {
        storyViewModel.getStoriesWithLocation().observe(this) { stories ->
            addMarkers(stories)
        }
    }

    private fun addMarkers(stories: List<Story>) {
        for (story in stories) {
            story.lat?.let { lat ->
                story.lon?.let { lon ->
                    val location = LatLng(lat, lon)
                    mMap.addMarker(MarkerOptions().position(location).title(story.name))
                }
            }
        }
    }
}
