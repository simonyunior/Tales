package com.example.tales.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.asLiveData
import androidx.paging.PagingData
import com.example.tales.data.StoryRepository
import com.example.tales.model.Story
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runBlockingTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever

@OptIn(ExperimentalCoroutinesApi::class)
class StoryViewModelTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private val repository = mock<StoryRepository>()
    private val viewModel = StoryViewModel(repository)

    @Test
    fun `when_getStories_should_return_data`() = runBlockingTest {
        val dummyStories = listOf(
            Story("1", "Story 1", "Description 1", "https://example.com/photo1.jpg", 0.0, 0.0),
            Story("2", "Story 2", "Description 2", "https://example.com/photo2.jpg", 0.0, 0.0)
        )
        val pagingData = PagingData.from(dummyStories)
        whenever(repository.getStoriesStream()).thenReturn(flowOf(pagingData))

        val result = mutableListOf<PagingData<Story>>()
        val job = launch {
            viewModel.getStories().asLiveData().observeForever { pagingData ->
                result.add(pagingData)
            }
        }

        assertEquals(1, result.size)
        job.cancel()
    }

    @Test
    fun `when_getStoriesWithLocation_should_return_data`() = runBlockingTest {
        val dummyToken = "Bearer token"
        val dummyStories = listOf(
            Story("1", "Story 1", "Description 1", "https://example.com/photo1.jpg", 0.0, 0.0),
            Story("2", "Story 2", "Description 2", "https://example.com/photo2.jpg", 0.0, 0.0)
        )

        whenever(repository.getToken()).thenReturn(flowOf(dummyToken))
        whenever(repository.getStoriesWithLocation(dummyToken)).thenReturn(dummyStories)

        val result = mutableListOf<List<Story>>()
        val job = launch {
            viewModel.getStoriesWithLocation().observeForever {
                result.add(it)
            }
        }

        assertEquals(1, result.size)
        assertEquals(dummyStories, result[0])
        job.cancel()
    }
}
